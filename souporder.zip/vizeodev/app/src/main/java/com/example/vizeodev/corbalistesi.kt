package com.example.vizeodev

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.Gravity
import android.view.View
import android.widget.CompoundButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.vizeodev.corbalistesi
import kotlinx.android.synthetic.main.activity_corbalistesi.*
import kotlinx.android.synthetic.main.toast.view.*

class corbalistesi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_corbalistesi)
        corba.setOnCheckedChangeListener{CompoundButton,b ->
            if(b){
                radioGroup.visibility= View.VISIBLE
                devam.visibility=View.VISIBLE
            }
        }
        var corbaismi=""
        var tasarim=layoutInflater.inflate(R.layout.toast,null)
        var toasttakiyazi=tasarim.textView4
        var toastozel=Toast(applicationContext)
        toastozel.view=tasarim
        toastozel.setGravity(Gravity.BOTTOM,0,0)
        toastozel.duration=Toast.LENGTH_LONG
        devam.setOnClickListener{
            if (mercimek.isChecked){
                corbaismi="Mercimek"
                toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

                Handler().postDelayed({
                    var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                    intent.putExtra("corba",corbaismi)
                    startActivity(intent)
                    finish()
                },3000)
                toastozel.show()


            }else if (ezogelin.isChecked){
            corbaismi="Ezogelin"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            Handler().postDelayed({
                var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()

        }else if (dugun.isChecked){
            corbaismi="Düğün"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            Handler().postDelayed({
                var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()

        }else if (Brokoli.isChecked){
            corbaismi="Brokoli"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            Handler().postDelayed({
                var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()

        }else if (mercimek.isChecked){
            corbaismi="Mercimek"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            Handler().postDelayed({
                var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()

        }
          else if (kellepaca.isChecked){
                corbaismi="Kelle Paça"
                toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

                Handler().postDelayed({
                    var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                    intent.putExtra("corba",corbaismi)
                    startActivity(intent)
                    finish()
                },3000)
                toastozel.show()


            }else if (yayla.isChecked){
            corbaismi="Yayla"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            Handler().postDelayed({
                var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()

        }else if (sehriye.isChecked){
            corbaismi="Şehriye"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            android.os.Handler().postDelayed({
                var intent= android.content.Intent(
                    applicationContext,
                    com.example.vizeodev.tarifveEkstralar::class.java
                )
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()

        } else if (domates.isChecked){
            corbaismi="Domates"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            Handler().postDelayed({
                var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()

        }else if (tarhana.isChecked){
            corbaismi="Tarhana"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            Handler().postDelayed({
                var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()

        }else if (mantar.isChecked){
            corbaismi="Mantar"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            Handler().postDelayed({
                var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()

        }else if (iskembe.isChecked){
            corbaismi="İşkembe"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            Handler().postDelayed({
                var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()

        }else if (tavuk.isChecked){
            corbaismi="Tavuk"
            toasttakiyazi.text="$corbaismi güzel seçim, lütfen bekleyiniz"

            Handler().postDelayed({
                var intent=Intent(applicationContext,tarifveEkstralar::class.java)
                intent.putExtra("corba",corbaismi)
                startActivity(intent)
                finish()
            },3000)
            toastozel.show()


        }else{
            val uyari=AlertDialog.Builder(this)
                uyari.setTitle("Uyarı!")
                uyari.setMessage("Lütfen Seçiminizi Yapınız")
                uyari.setIcon(R.drawable.logo1)
                uyari.setPositiveButton("Tekrar dene"){
                        DialogInterface,i ->

                }
                uyari.create().show()

            }
        }

        }
    }
