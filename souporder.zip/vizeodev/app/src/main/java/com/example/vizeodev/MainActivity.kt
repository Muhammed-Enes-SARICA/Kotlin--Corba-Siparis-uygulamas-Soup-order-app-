package com.example.vizeodev

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        object : CountDownTimer(5000,100){
            override fun onTick(p0: Long) {
                if (3000<p0&&p0<5000){
                    textView.setTextSize(textView.textSize*0.4.toFloat())
                }

            }

            override fun onFinish() {
                var intent=Intent(applicationContext,ikincisayfa::class.java)
                startActivity(intent)
                finish()

            }

        }.start()

        }
    }

