package com.example.vizeodev

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_siparisdetayi.*

class siparisdetayi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_siparisdetayi)

        var alinancorbaismi = intent.getStringExtra("corbaismi")
        var aci = intent.getStringExtra("aciorani")
        var tuz = intent.getStringExtra("tuzorani")
        var istekaktar = intent.getStringExtra("istek")
        var krema = intent.getStringExtra("krema")
        var kitir = intent.getStringExtra("kıtır")
        var nane = intent.getStringExtra("nane")
        var yağ = intent.getStringExtra("yağ")
        var limon = intent.getStringExtra("limon")
        var tozbiber = intent.getStringExtra("tozbiber")
        var kasar = intent.getStringExtra("kaşar")
        var terbiye = intent.getStringExtra("terbiye")
        var beyin = intent.getStringExtra("beyin")
        var dil = intent.getStringExtra("dil")
        var sarimsak = intent.getStringExtra("sarımsak")
        var sirke = intent.getStringExtra("sirke")

        textView2.text = "Bir  $alinancorbaismi Çorbası Çeeek ,$tuz ve $aci olsun"
        if (krema == null) {
            krema = ""
        } else {
            krema = "Krema,"
        }
        if (kitir == null) {
            kitir = ""
        } else {
            kitir = "Kitir,"
        }
        if (nane == null) {
            nane = ""
        } else {
            nane = "Nane,"
        }
        if (yağ == null) {
            yağ = ""
        } else {
            yağ = "Yağ,"
        }
        if (limon == null) {
            limon = ""
        } else {
            limon = "Limon,"
        }
        if (tozbiber == null) {
            tozbiber = ""
        } else {
            tozbiber = "Tozbiber,"
        }
        if (kasar == null) {
            kasar = ""
        } else {
            kasar = "Kaşar,"
        }
        if (terbiye == null) {
            terbiye = ""
        } else {
            terbiye = "Terbiye,"
        }
        if (beyin == null) {
            beyin = ""
        } else {
            beyin = "Beyin,"
        }
        if (dil == null) {
            dil = ""
        } else {
            dil = "Dil,"
        }
        if (sarimsak == null) {
            sarimsak = ""
        } else {
            sarimsak = "Sarımsak,"
        }
        if (sirke == null) {
            sirke = ""
        } else {
            sirke = "Sirke,"
        }
        textView8.text =
            "$krema$kitir$nane$yağ$tozbiber$kasar$limon$tozbiber$kasar$terbiye$beyin$dil$sarimsak$sirke"

        if (textView8.text == "") {
            textView3.visibility = View.INVISIBLE
            textView9.visibility = View.INVISIBLE

        }
        if (istekaktar != null) {
            textView11.text = "Ekstra isteğiniz $istekaktar"
        } else {
            textView11.visibility = View.INVISIBLE
        }
        object : CountDownTimer(5000, 10) {
            override fun onTick(p0: Long) {
                if (yenisiparis.visibility == View.VISIBLE) {
                    yenisiparis.visibility = View.INVISIBLE
                } else {
                    yenisiparis.visibility = View.VISIBLE
                }
            }

            override fun onFinish() {
                yenisiparis.visibility = View.VISIBLE
            }

        }.start()

        yenisiparis.setOnClickListener {
            var gecis = Intent(applicationContext, corbalistesi::class.java)
            startActivity(gecis)
            finish()
        }
        cikis.setOnClickListener {
            val uyari = AlertDialog.Builder(this@siparisdetayi)
            uyari.setIcon(R.drawable.quit)
            uyari.setTitle("Çıkış ")
            uyari.setMessage("Çıkmak İstediğinize Emin misiniz?")
            uyari.setNegativeButton("Hayır") { DialogInterface, i ->

            }
            uyari.setPositiveButton("Evet") { DialogInterface, i ->
                System.exit(0)
            }
            uyari.create().show()
        }
    }
}