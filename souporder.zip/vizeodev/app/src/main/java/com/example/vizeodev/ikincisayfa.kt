package com.example.vizeodev

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_ikincisayfa.*

class ikincisayfa : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ikincisayfa)
        Egirisi.setOnClickListener{
            Etik.visibility= View.VISIBLE
        }
        Ngirisi.setOnClickListener{
            if (Etik.visibility==View.VISIBLE){
                Ntik.visibility=View.VISIBLE
            }
        }
        E2girisi.setOnClickListener{
            if (Ntik.visibility==View.VISIBLE){
                E2tik.visibility=View.VISIBLE
            }
        }
        Sgirisi.setOnClickListener{
            if (E2tik.visibility==View.VISIBLE){
                Stik.visibility=View.VISIBLE
                progressBar.visibility=View.VISIBLE
                var intent= Intent(applicationContext,corbalistesi::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}